from django.contrib import admin
from .models import Filme, Ator, Genero

admin.site.register(Filme)
admin.site.register(Ator)
admin.site.register(Genero)

